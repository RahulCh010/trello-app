
export interface IList {
    cardtext: string;
    ID: string;
}

export class Card {
     name: string;
     cardtext: string;
     lists: IList[];
     ID: string;
}

export class List {
    cardtext: string;
    description: string;
    ID: string;
    listId: string;
}
