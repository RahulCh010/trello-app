import { Component, OnInit, OnDestroy } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormArray} from '@angular/forms';
import { CdkDragDrop, moveItemInArray, transferArrayItem } from '@angular/cdk/drag-drop';
import { Card, IList, List} from './Iboardlist';
import { ActivatedRoute } from '@angular/router';
import { CardTitleDialogComponent } from '../card-title-dialog/card-title-dialog.component';
import { CardTextDialogComponent } from '../card-text-dialog/card-text-dialog.component';
import { MatDialog, MatDialogRef } from '@angular/material';
import * as Actions from '../store/actions/board.action';
import { Store, select } from '@ngrx/store';
import TrelloState from '../store/state/state';
import { Observable, Subscription } from 'rxjs';
import { map } from 'rxjs/operators';
import { getAllBoardState } from '../store/selectors/selectors';
import { openCardTitleDialog, editCardTitleDialog, openCardTextDialog, editCardTextDialog } from '../store/actions/board.action';

@Component({
  selector: 'app-board-list',
  templateUrl: './board-list.component.html',
  styleUrls: ['./board-list.component.scss']
})

export class BoardListComponent implements OnInit, OnDestroy {
  boardname;
  cardList: Card[] = [];
  itemList: List[] = [];
  trelloCard$: Observable<Card[]>;
  TrelloSubscription: Subscription;
  cardlist: Card[];
  trelloError: Error = null;

  constructor(private formbuilder: FormBuilder,
              private route: ActivatedRoute,
              private store: Store<TrelloState>
  ) {
    // this.trelloCard$ = store.pipe(select('TrelloCard'));
    // this.TrelloSubscription = this.trelloCard$.subscribe(x => {
    //   if ( x !== undefined ) {
    //   this.cardlist = x[`TrelloCard`];
    //   this.trelloError = x[`TrelloError`]; // x["TrelloError"];
    //   }
    // });
    this.boardname = this.route.snapshot.params.id;
  }

  ngOnInit() {
    this.store.select(getAllBoardState).subscribe(data => {
      console.log(data);
      this.cardlist = data;
    });
  }

/*istanbull ignore next */
  ondrop(event: CdkDragDrop<any>) {
    if (event.previousContainer === event.container) {
      moveItemInArray(event.container.data.lists, event.previousIndex, event.currentIndex);
    } else {
      transferArrayItem(event.previousContainer.data.lists,
        event.container.data.lists,
        event.previousIndex,
        event.currentIndex);
    }
  }

  openAddCardTitleDialog() {
    this.store.dispatch(openCardTitleDialog());
  }

  editCard(card: Card) {
    this.store.dispatch(editCardTitleDialog({ payload: card }));
  }

  deleteCard(id: string) {
    const card = this.cardList.findIndex(c => c.ID === id);
    this.cardList.splice(card, 1);
    console.log(this.cardList);
    this.store.dispatch(Actions.DeleteCardAction({ payload: id }));
  }

  openCardTextDialog(card) {
    this.store.dispatch(Actions.openCardTextDialog({ payload: card }));
  }

  editCardText(cardid: string, list) {
    this.store.dispatch(editCardTextDialog({ payload: list }));
  }

  deleteCardText(id: string) {
    const cardText = this.itemList.findIndex(c => c.ID === id);
    this.itemList.splice(cardText, 1);
    this.store.dispatch(Actions.DeleteListAction({ payload: id }));
  }

  ngOnDestroy() {
 
  }
}
