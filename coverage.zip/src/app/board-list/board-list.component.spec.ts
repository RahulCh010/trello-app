import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { provideMockStore, MockStore } from '@ngrx/store/testing';
import { BoardListComponent } from './board-list.component';
import { RouterTestingModule } from '@angular/router/testing';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule, MatFormFieldModule, MatInputModule, MatCardModule, MatListModule, MatIconModule } from '@angular/material';
import { Store, select } from '@ngrx/store';
import TrelloState from '../store/state/state';
import { DragDropModule } from '@angular/cdk/drag-drop';
import { openCardTitleDialog, editCardTitleDialog, openCardTextDialog, editCardTextDialog } from '../store/actions/board.action';

describe('BoardListComponent', () => {
  let component: BoardListComponent;
  let fixture: ComponentFixture<BoardListComponent>;
  const initialState = [];
  let mockStore: MockStore<TrelloState>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [BoardListComponent],
      imports: [
        MatCardModule,
        MatButtonModule,
        MatFormFieldModule,
        MatInputModule,
        MatIconModule,
        DragDropModule,
        FormsModule,
        ReactiveFormsModule,
        RouterTestingModule,
        BrowserAnimationsModule
      ],
      providers: [
        provideMockStore({ initialState })
      ]
    })
      .compileComponents();
    mockStore = TestBed.get(Store);
    spyOn(mockStore, 'dispatch').and.callThrough();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BoardListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should dispatch OPEN_CardTitle_DIALOG action', () => {
    const expectedAction = {
      type: 'OPEN_CardTitle_DIALOG'
    };
    component.openAddCardTitleDialog();
    expect(mockStore.dispatch).toHaveBeenCalled();
    expect(mockStore.dispatch).toHaveBeenCalledWith(expectedAction);
  });

  it('should dispatch EDIT_CardTitle_DIALOG action', () => {
    const card = {
      name: 'card',
      cardtext: '',
      lists: [],
      ID: 'card_' + Math.random().toString(36).substr(2, 9),
    };
    const expectedAction = {
      type: 'EDIT_CardTitle_DIALOG',
      payload: card
    };

    component.editCard(card);
    expect(mockStore.dispatch).toHaveBeenCalled();
    expect(mockStore.dispatch).toHaveBeenCalledWith(expectedAction);
  });

  it('should dispatch DeleteCardAction', () => {
    const id = 'card_' + Math.random().toString(36).substr(2, 9);
    const expectedAction = {
      type: 'DeleteCard',
      payload: id,
    };
    component.deleteCard(id);
    expect(mockStore.dispatch).toHaveBeenCalled();
    expect(mockStore.dispatch).toHaveBeenCalledWith(expectedAction);
  });

  it('should dispatch OPEN_CardText_DIALOG action', () => {
    const card = {
      name: 'card',
      cardtext: '',
      lists: [],
      ID: 'card_' + Math.random().toString(36).substr(2, 9),
    };
    const expectedAction = {
      type: 'OPEN_CardText_DIALOG',
      payload: card,
    };
    component.openCardTextDialog(card);
    expect(mockStore.dispatch).toHaveBeenCalled();
    expect(mockStore.dispatch).toHaveBeenCalledWith(expectedAction);
  });

  it('should dispatch EDIT_CardText_DIALOG action', () => {
    const list = {
      cardtext: 'cardtext',
      description: 'description',
      list_id: '',
      ID: 'list_' + Math.random().toString(36).substr(2, 9),
    };
    const cardid = 'list_' + Math.random().toString(36).substr(2, 9);
    const expectedAction = {
      type: 'EDIT_CardText_DIALOG',
      payload: list
    };
    component.editCardText(cardid, list);
    expect(mockStore.dispatch).toHaveBeenCalled();
    expect(mockStore.dispatch).toHaveBeenCalledWith(expectedAction);
  });

  it('should dispatch DeleteListAction', () => {
    const id = 'list_' + Math.random().toString(36).substr(2, 9);
    const expectedAction = {
      type: 'DeleteList',
      payload: id,
    };
    component.deleteCardText(id);
    expect(mockStore.dispatch).toHaveBeenCalled();
    expect(mockStore.dispatch).toHaveBeenCalledWith(expectedAction);
  });

});
