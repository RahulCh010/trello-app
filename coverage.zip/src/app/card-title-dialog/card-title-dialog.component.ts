import { Component, OnInit, Inject } from '@angular/core';
import { provideMockStore, MockStore } from '@ngrx/store/testing';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule, MatFormFieldModule, MatInputModule, MatCardModule, MatListModule, MatIconModule } from '@angular/material';
import { Store, select } from '@ngrx/store';
import { MatDialogRef, MAT_DIALOG_DATA, MatDialogModule } from '@angular/material';
import { RouterTestingModule } from '@angular/router/testing';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatToolbarModule } from '@angular/material/toolbar';

@Component({
  selector: 'app-card-title-dialog',
  templateUrl: './card-title-dialog.component.html',
  styleUrls: ['./card-title-dialog.component.scss']
})
export class CardTitleDialogComponent implements OnInit {

 form: FormGroup;

  constructor(
    private formBuilder: FormBuilder,
    public dialogRef: MatDialogRef<CardTitleDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data
  ) {}

  ngOnInit() {
    console.log(this.data);
    if (this.data.option === 'edit') {
    this.form = this.formBuilder.group({
      ID : [this.data.card.ID],
      name : [ this.data.card.name , [Validators.required]]
    });
    } else {
      this.form = this.formBuilder.group({
      ID : [''],
      name : [ '' , [Validators.required]]
    });
    }
  }

  onClose(): void {
    this.dialogRef.close();
  }
  }
