import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { provideMockStore, MockStore } from '@ngrx/store/testing';
import { CardTitleDialogComponent } from './card-title-dialog.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule, MatFormFieldModule, MatInputModule, MatCardModule, MatListModule, MatIconModule } from '@angular/material';
import { Store, select } from '@ngrx/store';
import { MatDialogRef, MAT_DIALOG_DATA, MatDialogModule } from '@angular/material';
import { RouterTestingModule } from '@angular/router/testing';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatToolbarModule } from '@angular/material/toolbar';

describe('CardTitleDialogComponent', () => {
  let component: CardTitleDialogComponent;
  let fixture: ComponentFixture<CardTitleDialogComponent>;
  const initialState = [];
  const cardData = {
     data: {},
      cardid: 'list_',
      popup: 'create'
  };
  const dialogMock = {
    close: () => { }
   };
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CardTitleDialogComponent ],
       imports: [
        MatCardModule,
        MatDialogModule,
        MatButtonModule,
        MatFormFieldModule,
        MatInputModule,
        MatIconModule,
        FormsModule,
        MatToolbarModule,
        ReactiveFormsModule,
        RouterTestingModule,
        BrowserAnimationsModule
      ],
      providers: [
        provideMockStore({ initialState }),
        { provide: MAT_DIALOG_DATA, useValue: cardData },
        { provide: MatDialogRef, useValue: dialogMock }

      ]
     })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CardTitleDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
     expect(component).toBeTruthy();
  });

  it('should close dialog on clicking cancel button', () => {
    const closeSpy = spyOn(component.dialogRef, 'close').and.callThrough();
    component.onClose();
    expect(closeSpy).toHaveBeenCalled();
  });
});
