import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { RouterTestingModule } from '@angular/router/testing';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatButtonModule, MatFormFieldModule, MatInputModule, MatCardModule, MatListModule, MatIconModule } from '@angular/material';

@Component({
  selector: 'app-card-text-dialog',
  templateUrl: './card-text-dialog.component.html',
  styleUrls: ['./card-text-dialog.component.scss']
})
export class CardTextDialogComponent implements OnInit {

  textform: FormGroup;

  constructor(
    private formBuilder: FormBuilder,
    public dialogRef: MatDialogRef<CardTextDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public cardData
  ) {}

  ngOnInit() {
    console.log(this.cardData);
    this.textform = this.formBuilder.group({
      ID : [this.cardData.data.ID],
      cardtext : [ this.cardData.data.cardtext , [Validators.required]],
      description : [ this.cardData.data.description , [Validators.required]]
    });
  }

  onClose(): void {
    this.dialogRef.close();
  }

  }
