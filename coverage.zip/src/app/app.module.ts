import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { TrelloHomeComponent } from './trello-home/trello-home.component';
import { CreateBoardComponent } from './create-board/create-board.component';
import { BoardListComponent} from './board-list/board-list.component';
import { MaterialModule } from './material/material.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DragDropModule } from '@angular/cdk/drag-drop';
import { StoreModule } from '@ngrx/store';
import { BoardReducers } from './store/reducers/board.reducers';
import { StoreDevtoolsModule } from '@ngrx/store-devtools';
import { environment } from '../environments/environment';
import { CardTitleDialogComponent } from './card-title-dialog/card-title-dialog.component';
import { CardTextDialogComponent } from './card-text-dialog/card-text-dialog.component';
import { EffectsModule } from '@ngrx/effects';
import { CardTitleDialog } from './store/effects/board.effects';
import { CardTextDialog } from './store/effects/cardlist.effects';

@NgModule({
  declarations: [
    AppComponent,
    TrelloHomeComponent,
    CreateBoardComponent,
    BoardListComponent,
    CardTitleDialogComponent,
    CardTextDialogComponent,
    ],

  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    MaterialModule,
    DragDropModule,
    FormsModule,
    ReactiveFormsModule,
    StoreModule.forRoot({ TrelloCard: BoardReducers }),
    EffectsModule.forRoot([CardTitleDialog, CardTextDialog]),
    StoreDevtoolsModule.instrument({
      maxAge: 25,
      logOnly: environment.production,
    }),
    ],

    entryComponents : [CardTitleDialogComponent, CardTextDialogComponent],

  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
