import { Card , IList , List} from '../../board-list/Iboardlist';
export default class TrelloState {
  TrelloCard: Array<Card>;
  TrelloError: Error;
}

export const initializeState = (): TrelloState => {
  return { TrelloCard: Array<Card>(), TrelloError: null };
};



