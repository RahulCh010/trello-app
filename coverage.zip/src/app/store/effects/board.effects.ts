import { Injectable } from '@angular/core';
import { MatDialog } from '@angular/material';
import { Store, Action, select } from '@ngrx/store';
import { Actions, Effect, ofType, createEffect } from '@ngrx/effects';
import { Router } from '@angular/router';
import { map, exhaustMap, mergeMap } from 'rxjs/operators';
import TrelloState from '../state/state';
import { CardTitleDialogComponent } from '../../card-title-dialog/card-title-dialog.component';
import { AddCardAction, EditCardAction, openCardTitleDialog, closeCardTitleDialog, editCardTitleDialog,
    } from '../actions/board.action';
import { Card, List } from '../../board-list/Iboardlist';

@Injectable()
export class CardTitleDialog {

    constructor(private actions: Actions, private dialog: MatDialog, private router: Router) { }

    createCardTitleDialogEffect = createEffect(() => this.actions.pipe(
        ofType(openCardTitleDialog),
        exhaustMap(dialog => {
            const dialogRef = this.dialog.open(CardTitleDialogComponent, {
                width: '500px',
                data: {
                    option: 'create'
                }
            });
            return dialogRef.afterClosed();
        }),

      mergeMap((data) => {
            if (data === undefined || data.name  === '') {
                return [closeCardTitleDialog()];
            }
            const card: Card = {
                 name: data.name,
                 cardtext : '',
                 lists: [],
                 ID: 'card_' + Math.random().toString(36).substr(2, 9),
            };

            return [
            AddCardAction({ payload: card })

            ];

        }),
      )
    );

    editCardTitleDialog = createEffect(() => this.actions.pipe(
        ofType(editCardTitleDialog),
        exhaustMap(action => {
            const dialogRef = this.dialog.open(CardTitleDialogComponent, {
                width: '500px',
                data: {
                    card: action.payload,
                    option: 'edit'
                }
            });
            return dialogRef.afterClosed()
                .pipe(map((data) => ({ payload: action.payload, response: data })));
        }),
        mergeMap((data) => {
            if (data.response === undefined || data.response.name === '') {
                return [closeCardTitleDialog()];
            }

            const card: Card = {
                ID: data.payload.ID,
                name: data.response.name,
                cardtext : '',
                lists: data.payload.lists,
            };
            return [
                EditCardAction({ payload: card })
            ];
        }),
    )
    );
}


