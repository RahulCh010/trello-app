import { Injectable } from '@angular/core';
import { MatDialog } from '@angular/material';
import { Store, Action, select } from '@ngrx/store';
import { Actions, Effect, ofType, createEffect } from '@ngrx/effects';
import { Router } from '@angular/router';
import { map, exhaustMap, mergeMap } from 'rxjs/operators';
import TrelloState from '../state/state';
import { CardTextDialogComponent } from '../../card-text-dialog/card-text-dialog.component';
import { AddListAction, EditListAction, openCardTextDialog, closeCardTextDialog, editCardTextDialog } from '../actions/board.action';
import { Card, List } from '../../board-list/Iboardlist';


@Injectable()

export class CardTextDialog {

    constructor(private actions: Actions, private dialog: MatDialog, private router: Router) { }
    createCardTextDialogEffect = createEffect(() => this.actions.pipe(
        ofType(openCardTextDialog),
        exhaustMap(dialog => {
            console.log(dialog);
            const dialogRef = this.dialog.open(CardTextDialogComponent, {
                width: '500px',
                 data:
                      {
                        data: {},
                        cardid: dialog[`ID`],
                        popup: 'create'
                      }
            });
            return dialogRef.afterClosed()
             .pipe(map((data) => ({ cardData: dialog, response: data })));
        }),

      mergeMap((data) => {
            if (data === undefined || data.response.cardtext  === '') {
                return [closeCardTextDialog()];
            }

            const list: List = {
                 cardtext: data.response.cardtext,
                 description: data.response.description,
                 listId: data.cardData.payload.ID,
                 ID: 'list_' + Math.random().toString(36).substr(2, 9),
            };

            return [
            AddListAction({ payload: list })

            ];

        }),
      )
    );

    editCardTextDialog = createEffect(() => this.actions.pipe(
        ofType(editCardTextDialog),
        exhaustMap(action => {
           // const cardText = this.trelloBoardService.getAllCardTextList().find(c => c.ID === listid);
            const dialogRef = this.dialog.open(CardTextDialogComponent, {
                width: '500px',
                data:
                  {
                   data: action.payload,
                   cardid: action.payload,
                   popup: 'edit',
                  }
            });
            return dialogRef.afterClosed()
                .pipe(map((data) => ({ cardData: action, response: data })));
        }),
        mergeMap((data) => {
            if (data.response === undefined || data.response.cardtext === '') {
                return [closeCardTextDialog()];
            }

            const list: List = {
                ID: data.response.ID,
                cardtext: data.response.cardtext,
                description : data.response.description,
                listId: data.cardData.payload.listId,
            };
            return [
                EditListAction({ payload: list })
            ];
        }),
    )
    );
}


