import { createAction, props } from '@ngrx/store';
import { Card, IList, List} from '../../board-list/IboardList';

export const AddCardAction = createAction(
    'AddCard', props<{ payload: Card }>()
);

export const EditCardAction = createAction(
    'EditCard', props<{ payload: Card }>()
);

export const DeleteCardAction = createAction(
  'DeleteCard', props<{ payload: string }>()
);

export const AddListAction = createAction(
  'AddList', props<{ payload: List}>()
);

export const EditListAction = createAction(
    'EditList', props<{ payload: List }>()
);

export const DeleteListAction = createAction(
   'DeleteList', props<{ payload: string }>()
);

export const openCardTitleDialog = createAction(
   'OPEN_CardTitle_DIALOG'
);

export const closeCardTitleDialog = createAction(
   'CLOSE_CardTitle_DIALOG'
);
export const editCardTitleDialog = createAction(
   'EDIT_CardTitle_DIALOG', props<{payload: Card}>()
);
export const openCardTextDialog = createAction(
   'OPEN_CardText_DIALOG', props<{payload: Card}>()
);

export const closeCardTextDialog = createAction(
   'CLOSE_CardText_DIALOG'
);
export const editCardTextDialog = createAction(
   'EDIT_CardText_DIALOG', props<{payload: List}>()
);

