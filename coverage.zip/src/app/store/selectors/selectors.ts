import { createFeatureSelector , createSelector } from '@ngrx/store';
import TrelloState from '../state/state';

export const getBoardsState = createFeatureSelector<TrelloState>('TrelloCard');
export const getAllBoardState = createSelector( getBoardsState,
    (state: TrelloState) => state.TrelloCard);

