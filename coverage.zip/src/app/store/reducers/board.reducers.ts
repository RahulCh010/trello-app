import { Action, createReducer, on } from '@ngrx/store';
import * as Actions from '../actions/board.action';
import { Card, List} from '../../board-list/IboardList';
import TrelloState, { initializeState } from '../state/state';

export const intialState = initializeState();
const reducer = createReducer(
  intialState,

on(Actions.AddCardAction, (state: TrelloState, { payload }) => {
    console.log(state);
    return { ...state, TrelloCard: [...state.TrelloCard, payload], TrelloError: null };
}),

on(Actions.EditCardAction, (state: TrelloState, { payload }) => {
  const index = state.TrelloCard.findIndex(c => c.ID === payload.ID);
  state.TrelloCard[index] = payload;
  return { ...state, TrelloError: null };
}),

on(Actions.DeleteCardAction, (state: TrelloState, { payload }) => {
  console.log(payload);
  const cardIndex = state.TrelloCard.findIndex(c => c.ID === payload);
  state.TrelloCard.splice(cardIndex, 1);
  return { ...state, TrelloError: null };
}),

on(Actions.AddListAction, (state: TrelloState, { payload }) => {
  const index = state.TrelloCard.findIndex(x => x.ID === payload.listId);
  state.TrelloCard[index].lists.push(payload);
  return { ...state, TrelloError: null };
}),

on(Actions.EditListAction, (state: TrelloState, { payload }) => {
  const cardIndex = state.TrelloCard.findIndex(x => x.ID === payload.listId);
  const listIndex = state.TrelloCard[cardIndex].lists.findIndex(c => c.ID === payload.ID);
  state.TrelloCard[cardIndex].lists[listIndex] = payload;
  return { ...state, TrelloError: null };
}),

on(Actions.DeleteListAction, (state: TrelloState, { payload }) => {
  console.log(payload);
  const cardText = state.TrelloCard.findIndex(c => c.ID === payload);
  state.TrelloCard[cardText].lists.splice(cardText, 1);
  return { ...state, TrelloError: null };
  })

);

export function BoardReducers(state: TrelloState | undefined, action: Action): TrelloState {
  return reducer(state, action);
}
