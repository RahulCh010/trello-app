
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { CreateBoardComponent } from './create-board.component';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import { RouterTestingModule } from '@angular/router/testing';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatButtonModule, MatFormFieldModule, MatInputModule, MatCardModule, MatListModule, MatIconModule } from '@angular/material';

describe('CreateBoardComponent', () => {
  let fixture: ComponentFixture<CreateBoardComponent>;
  let component: any;
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [CreateBoardComponent],
      imports: [
        MatCardModule,
        MatButtonModule,
        MatFormFieldModule,
        MatInputModule,
        FormsModule,
        ReactiveFormsModule,
        RouterTestingModule,
        BrowserAnimationsModule
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CreateBoardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
     expect(component).toBeTruthy();
  });

  it('should create a form with one controls', () => {
    expect(component.angForm.contains('BoardName')).toBeTruthy();
  });

  it('should make the Board Name control required', () => {
    const control = component.angForm.get('BoardName');
    control.setValue('');
    expect(control.valid).toBeFalsy();
  });

  it('Board Name field validity', () => {
    const BoardName = component.angForm.controls.BoardName;
    expect(BoardName.valid).toBeFalsy();

    let errors = {};
    BoardName.setValue('');
    errors = BoardName.errors || {};
    expect(errors).toBeTruthy();
  });

  it('should call navigate with correct params', () => {
      spyOn(component.router, 'navigate');
      component.createBoard();
      expect(component.router.navigate).toHaveBeenCalledWith(['board-list/']);
    });

});
